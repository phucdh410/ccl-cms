Run the development server:

```bash
npm run dev